from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.http import require_POST  # ← NEW
from .runner import start_all_scripts, stop_all_scripts, get_process_status, run_compiler, run_modem  # ← NEW
import psutil
import os

SCRIPT_DIR = r"C:\Users\aushr\Music\vik"
EXCLUDED_SCRIPTS = {"Compiler.py", "modem_reboot.py"}

def home(request):
    try:
        scripts = [
            f for f in os.listdir(SCRIPT_DIR)
            if f.endswith(".py") and f not in EXCLUDED_SCRIPTS
        ]
        scripts.sort()
    except FileNotFoundError:
        scripts = []

    return render(request, "launcher/index.html", {
        "scripts": scripts
    })

def start_script(request):
    if request.method == "POST":
        script_name = request.GET.get("script")
        if script_name:
            result = start_all_scripts(script_name)
        else:
            result = start_all_scripts()
        return JsonResponse(result)
    return JsonResponse({"error": "POST required"}, status=405)

def stop_script(request):
    if request.method == "POST":
        result = stop_all_scripts()
        return JsonResponse(result)
    return JsonResponse({"error": "POST required"}, status=405)

def get_status(request):
    return JsonResponse(get_process_status())

def system_metrics(request):
    cpu_usage = psutil.cpu_percent(interval=0.2)
    return JsonResponse({
        "cpu_usage": round(cpu_usage, 1)
    })

# ← NEW VIEWS
@require_POST
def run_compiler(request):
    result = run_compiler()
    return JsonResponse(result)

@require_POST
def run_modem(request):
    result = run_modem()
    return JsonResponse(result)
