from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('start-script/', views.start_script, name='start_script'),
    path('stop-script/', views.stop_script, name='stop_script'),
    path('get-status/', views.get_status, name='get_status'),
    path("system-metrics/", views.system_metrics, name="system_metrics"),
    path('run-compiler/', views.run_compiler, name='run_compiler'),  # ← NEW
    path('run-modem/', views.run_modem, name='run_modem'),          # ← NEW
]
