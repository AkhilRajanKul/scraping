function getCookie(name) {
  let cookieValue = null;
  if (document.cookie && document.cookie !== "") {
    const cookies = document.cookie.split(";");
    for (const cookie of cookies) {
      const c = cookie.trim();
      if (c.startsWith(name + "=")) {
        cookieValue = decodeURIComponent(c.substring(name.length + 1));
        break;
      }
    }
  }
  return cookieValue;
}

async function postAction(url) {
  const csrftoken = getCookie("csrftoken");

  const response = await fetch(url, {
    method: "POST",
    credentials: "same-origin",
    headers: {
      "X-Requested-With": "XMLHttpRequest",
      "X-CSRFToken": csrftoken,
    },
  });

  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }

  return response.json();
}

const logBox = document.querySelector(".terminal");
const batchState = document.getElementById("batch-state");
const progressValue = document.getElementById("progress-value");
const cpuValue = document.getElementById("cpu-value");
const modemState = document.getElementById("modem-state");
const statusTableBody = document.querySelector(".status-panel tbody");
const scriptGrid = document.getElementById("scriptGrid");

const timerInput = document.getElementById("timer-input");
const timerUnit = document.getElementById("timer-unit");
const timerDisplay = document.getElementById("timer-display");

let timerInterval = null;
let timerRunning = false;
let timerDurationSeconds = 0;
let timerRemainingSeconds = 0;
let autoCycleEnabled = false;
let timerWasStoppedManually = false;

let lastLogCount = 0;

function addLog(message) {
  const line = document.createElement("div");
  const now = new Date().toLocaleTimeString();
  line.textContent = `[${now}] ${message}`;
  logBox.appendChild(line);
  logBox.scrollTop = logBox.scrollHeight;
}

function formatTime(totalSeconds) {
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return [hours, minutes, seconds]
    .map((v) => String(v).padStart(2, "0"))
    .join(":");
}

function getSelectedDurationSeconds() {
  const value = parseInt(timerInput.value || "0", 10);
  const unit = timerUnit.value;

  if (unit === "hours") return value * 3600;
  if (unit === "minutes") return value * 60;
  return value;
}

function updateTimerDisplay() {
  timerDisplay.textContent = formatTime(timerRemainingSeconds);
}

function stopTimerLoop() {
  if (timerInterval) {
    clearInterval(timerInterval);
    timerInterval = null;
  }
  timerRunning = false;
  autoCycleEnabled = false;
}

function stopTimerManually() {
  timerWasStoppedManually = true;
  stopTimerLoop();
  addLog("Timer stopped");
  timerRemainingSeconds = getSelectedDurationSeconds();
  updateTimerDisplay();
}

function waitForBatchToFinish() {
  return new Promise((resolve) => {
    const poll = setInterval(async () => {
      try {
        const response = await fetch("/get-status/", {
          method: "GET",
          credentials: "same-origin",
          headers: {
            "X-Requested-With": "XMLHttpRequest",
          },
        });

        const data = await response.json();

        if (!data.running) {
          clearInterval(poll);
          resolve();
        }
      } catch (error) {
        clearInterval(poll);
        resolve();
      }
    }, 3000);
  });
}

async function startTimerLoop() {
  stopTimerLoop();
  timerWasStoppedManually = false;

  timerDurationSeconds = getSelectedDurationSeconds();
  if (timerDurationSeconds <= 0) {
    addLog("Timer value must be greater than 0");
    return;
  }

  timerRemainingSeconds = timerDurationSeconds;
  autoCycleEnabled = true;
  timerRunning = true;
  updateTimerDisplay();
  addLog("Timer started");

  const tick = async () => {
    if (!autoCycleEnabled) {
      stopTimerLoop();
      return;
    }

    timerRemainingSeconds -= 1;

    if (timerRemainingSeconds <= 0) {
      timerRemainingSeconds = 0;
      updateTimerDisplay();
      stopTimerLoop();

      try {
        const result = await postAction("/start-script/");
        addLog(result.status);
        await waitForBatchToFinish();
      } catch (error) {
        addLog("Batch start failed");
        console.error(error);
      }

      if (!timerWasStoppedManually) {
        startTimerLoop();
      }
      return;
    }

    updateTimerDisplay();
  };

  timerInterval = setInterval(tick, 1000);
}

async function refreshStatus() {
  try {
    const response = await fetch("/get-status/", {
      method: "GET",
      credentials: "same-origin",
      headers: {
        "X-Requested-With": "XMLHttpRequest",
      },
    });

    if (!response.ok) {
      throw new Error(`Status request failed: ${response.status}`);
    }

    const data = await response.json();

    batchState.textContent = data.current || "idle";
    modemState.textContent = data.running ? "RUNNING" : "READY";
    progressValue.textContent = data.progress || "0/0";

    if (Array.isArray(data.logs)) {
      for (let i = lastLogCount; i < data.logs.length; i++) {
        addLog(data.logs[i]);
      }
      lastLogCount = data.logs.length;
    }

    statusTableBody.innerHTML = `
      <tr>
        <td>Batch</td>
        <td>
          <span class="badge ${data.running ? "running" : "completed"}">
            ${data.running ? "Running" : "Completed"}
          </span>
        </td>
        <td>---</td>
        <td>${data.progress || "0/0"}</td>
      </tr>
    `;
  } catch (error) {
    addLog("Failed to refresh status");
    console.error(error);
  }
}

async function refreshCpuUsage() {
  try {
    const response = await fetch("/system-metrics/", {
      method: "GET",
      credentials: "same-origin",
      headers: {
        "X-Requested-With": "XMLHttpRequest",
      },
    });

    if (!response.ok) {
      throw new Error(`CPU request failed: ${response.status}`);
    }

    const data = await response.json();

    if (cpuValue) {
      cpuValue.textContent = `${data.cpu_usage}%`;
    }
  } catch (error) {
    if (cpuValue) {
      cpuValue.textContent = "--%";
    }
    console.error(error);
  }
}

async function handleAction(action) {
  if (action === "start-all") {
    const result = await postAction("/start-script/");
    addLog(result.status);
    await refreshStatus();
    return;
  }

  if (action === "stop-all") {
    stopTimerManually();
    const result = await postAction("/stop-script/");
    addLog(result.status);
    await refreshStatus();
    return;
  }

  if (action === "refresh") {
    await refreshStatus();
    addLog("Status refreshed");
    return;
  }

  // ← NEW: Manual Modem Reboot
  if (action === "reboot") {
    try {
      const result = await postAction("/run-modem/");
      addLog(`Modem: ${result.status}`);
    } catch (error) {
      addLog("Modem reboot failed");
      console.error(error);
    }
    return;
  }

  // ← NEW: Manual Compiler (optional button)
  if (action === "run-compiler") {
    try {
      const result = await postAction("/run-compiler/");
      addLog(`Compiler: ${result.status}`);
    } catch (error) {
      addLog("Compiler failed");
      console.error(error);
    }
    return;
  }

  if (action === "timer-start") {
    await startTimerLoop();
    return;
  }

  if (action === "timer-stop") {
    stopTimerManually();
    return;
  }

  addLog(`${action} triggered`);
}

document.querySelectorAll("[data-action]").forEach((btn) => {
  btn.addEventListener("click", async () => {
    const action = btn.dataset.action;
    try {
      await handleAction(action);
    } catch (error) {
      addLog("Action failed");
      console.error(error);
    }
  });
});

if (scriptGrid) {
  scriptGrid.addEventListener("click", async (e) => {
    const btn = e.target.closest(".script-card");
    if (!btn) return;

    const scriptName = btn.dataset.script;
    if (!scriptName) return;

    try {
      addLog(`${scriptName} clicked`);
      const result = await postAction(
        `/start-script/?script=${encodeURIComponent(scriptName)}`
      );
      addLog(result.status || `${scriptName} started`);
      await refreshStatus();
    } catch (error) {
      addLog(`Failed to start ${scriptName}`);
      console.error(error);
    }
  });
}

timerInput.addEventListener("change", () => {
  if (timerRunning) {
    startTimerLoop();
  } else {
    timerRemainingSeconds = getSelectedDurationSeconds();
    updateTimerDisplay();
  }
});

timerUnit.addEventListener("change", () => {
  if (timerRunning) {
    startTimerLoop();
  } else {
    timerRemainingSeconds = getSelectedDurationSeconds();
    updateTimerDisplay();
  }
});

setInterval(refreshStatus, 3000);
setInterval(refreshCpuUsage, 3000);

refreshStatus();
refreshCpuUsage();
